#define _CRT_SECURE_NO_WARNINGS
#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include <d3d11.h>
#include <tchar.h>
#include <vector>
#include <string>
#include <windows.h>
#include <algorithm>
#include <iostream>
#include <dwmapi.h>
#include <fstream>
#include <urlmon.h>
#include <wininet.h>
#include <cstdlib>
#include <direct.h>
#include <sstream>

#include "font_data.h" 
#include "json.hpp"
using json = nlohmann::json;

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "d3dcompiler.lib")
#pragma comment(lib, "dwmapi.lib")
#pragma comment(lib, "urlmon.lib")
#pragma comment(lib, "wininet.lib")

#define IDI_ICON1 101 
static bool g_CanDrag = true;

const char* DB_URL = "https://cdn.discordapp.com/detectables/games.json";
const char* DB_FILENAME = "games_cache.temp";
const char* CONFIG_FILENAME = "chill_x_quest.config";

const std::string CURRENT_VERSION = "1.0.5";

std::string GetGitHubAPIResponse(const char* url) {
    HINTERNET hInternet = InternetOpenA("ChillXQuest_Updater/1.0", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
    if (!hInternet) return "";
    HINTERNET hConnect = InternetOpenUrlA(hInternet, url, NULL, 0, INTERNET_FLAG_RELOAD, 0);
    if (!hConnect) { InternetCloseHandle(hInternet); return ""; }

    std::string response;
    char buffer[4096];
    DWORD bytesRead = 0;
    while (InternetReadFile(hConnect, buffer, sizeof(buffer), &bytesRead) && bytesRead > 0) {
        response.append(buffer, bytesRead);
    }
    InternetCloseHandle(hConnect);
    InternetCloseHandle(hInternet);
    return response;
}

void CheckForUpdates() {
    std::string apiResponse = GetGitHubAPIResponse("https://api.github.com/repos/kayzedevx0/Discord-Quest-Completer/releases/latest");
    if (apiResponse.empty()) return;

    try {
        json releaseData = json::parse(apiResponse);
        std::string latestVersion = releaseData.value("tag_name", "");

        if (!latestVersion.empty() && (latestVersion[0] == 'v' || latestVersion[0] == 'V')) {
            latestVersion = latestVersion.substr(1);
        }

        if (latestVersion > CURRENT_VERSION && !latestVersion.empty()) {
            std::string downloadUrl = "";
            if (releaseData.contains("assets") && releaseData["assets"].is_array()) {
                for (auto& asset : releaseData["assets"]) {
                    std::string assetName = asset.value("name", "");
                    if (assetName.find(".exe") != std::string::npos) {
                        downloadUrl = asset.value("browser_download_url", "");
                        break;
                    }
                }
            }

            if (!downloadUrl.empty()) {
                char myPath[MAX_PATH];
                GetModuleFileNameA(NULL, myPath, MAX_PATH);
                std::string currentExe(myPath);
                std::string oldExe = currentExe + ".old";
                std::string newExe = currentExe + ".new";

                HRESULT hr = URLDownloadToFileA(NULL, downloadUrl.c_str(), newExe.c_str(), 0, NULL);
                if (SUCCEEDED(hr)) {
                    MoveFileExA(currentExe.c_str(), oldExe.c_str(), MOVEFILE_REPLACE_EXISTING);
                    MoveFileExA(newExe.c_str(), currentExe.c_str(), MOVEFILE_REPLACE_EXISTING);

                    STARTUPINFOA si; ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
                    PROCESS_INFORMATION pi; ZeroMemory(&pi, sizeof(pi));
                    CreateProcessA(NULL, (LPSTR)currentExe.c_str(), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi);

                    exit(0);
                }
            }
        }
    }
    catch (...) {}
}

void DeleteDirectoryRecursively(const std::string& directory) {
    std::string pattern = directory + "\\*.*";
    WIN32_FIND_DATAA fd;
    HANDLE hFind = FindFirstFileA(pattern.c_str(), &fd);

    if (hFind != INVALID_HANDLE_VALUE) {
        do {
            std::string fileName = fd.cFileName;
            if (fileName != "." && fileName != "..") {
                std::string filePath = directory + "\\" + fileName;

                if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
                    DeleteDirectoryRecursively(filePath);
                }
                else {
                    SetFileAttributesA(filePath.c_str(), FILE_ATTRIBUTE_NORMAL);
                    DeleteFileA(filePath.c_str());
                }
            }
        } while (FindNextFileA(hFind, &fd));
        FindClose(hFind);
    }

    SetFileAttributesA(directory.c_str(), FILE_ATTRIBUTE_NORMAL);
    RemoveDirectoryA(directory.c_str());
}

void CleanupTempFiles() {
    SetFileAttributesA(DB_FILENAME, FILE_ATTRIBUTE_NORMAL);
    DeleteFileA(DB_FILENAME);

    char buffer[MAX_PATH];
    GetModuleFileNameA(NULL, buffer, MAX_PATH);
    std::string path(buffer);
    size_t lastSlash = path.find_last_of("\\/");
    std::string rootDir = path.substr(0, lastSlash);

    std::string fakeGamesDir = rootDir + "\\fake_games";
    DeleteDirectoryRecursively(fakeGamesDir);
}

// Crimson Noir Palette Constants
const ImVec4 colPrimary = ImVec4(0.545f, 0.361f, 0.965f, 1.0f); // #8B5CF6
const ImVec4 colBackground = ImVec4(0.051f, 0.043f, 0.102f, 1.0f); // #0D0B1A
const ImVec4 colSecondary = ImVec4(0.129f, 0.102f, 0.227f, 1.0f); // #211A3A
const ImVec4 colAccent = ImVec4(0.769f, 0.710f, 0.992f, 1.0f); // #C4B5FD
const ImVec4 colTextLight = ImVec4(0.961f, 0.953f, 1.0f, 1.0f); // #F5F3FF
const ImVec4 colTextGrey = ImVec4(0.690f, 0.650f, 0.820f, 1.0f);
const ImVec4 colBoxBg = ImVec4(0.129f, 0.102f, 0.227f, 0.72f);
const ImVec4 colBorder = ImVec4(0.769f, 0.710f, 0.992f, 0.24f);
const ImVec4 colBtnStop = ImVec4(0.40f, 0.16f, 0.55f, 1.0f);

struct GameInfo {
    std::string name;
    std::string id;
    std::vector<std::string> executables;
    std::vector<std::string> executablePaths;
};

std::string ToLower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return std::tolower(c); });
    return s;
}

std::vector<GameInfo> FetchGameDatabase() {
    std::vector<GameInfo> db;
    DeleteUrlCacheEntryA(DB_URL);
    HRESULT hr = URLDownloadToFileA(NULL, DB_URL, DB_FILENAME, 0, NULL);
    SetFileAttributesA(DB_FILENAME, FILE_ATTRIBUTE_HIDDEN);

    std::ifstream f(DB_FILENAME);
    if (f.is_open()) {
        try {
            json data = json::parse(f);
            if (data.is_array()) {
                for (auto& item : data) {
                    GameInfo game;
                    game.name = item.value("name", "Unknown");

                    if (item["id"].is_string()) game.id = item.value("id", "0");
                    else if (item["id"].is_number()) game.id = std::to_string(item["id"].get<long long>());
                    else game.id = "0";

                    if (item.contains("executables") && item["executables"].is_array()) {
                        for (auto& exeEntry : item["executables"]) {
                            if (exeEntry.value("os", "unknown") != "win32") continue;
                            std::string exePath = exeEntry.value("name", "");
                            if (exePath.empty()) continue;

                            std::string exeName = exePath;
                            size_t lastSlash = exeName.find_last_of("/\\");
                            if (lastSlash != std::string::npos) exeName = exeName.substr(lastSlash + 1);

                            bool exists = false;
                            for (size_t i = 0; i < game.executables.size(); ++i) {
                                if (game.executables[i] == exeName && game.executablePaths[i] == exePath) {
                                    exists = true;
                                    break;
                                }
                            }
                            if (!exists) {
                                game.executables.push_back(exeName);
                                game.executablePaths.push_back(exePath);
                            }
                        }
                    }
                    if (!game.executables.empty()) db.push_back(game);
                }
            }
        }
        catch (...) { db.push_back({ "Database Error", "0", {}, {} }); }
        f.close();
    }
    else { db.push_back({ "Connection Error", "0", {}, {} }); }
    return db;
}

void TextCentered(std::string text) {
    auto windowWidth = ImGui::GetContentRegionAvail().x;
    auto windowHeight = ImGui::GetContentRegionAvail().y;
    auto textWidth = ImGui::CalcTextSize(text.c_str()).x;
    auto textHeight = ImGui::CalcTextSize(text.c_str()).y;
    ImGui::SetCursorPosX((windowWidth - textWidth) * 0.5f);
    ImGui::SetCursorPosY((windowHeight - textHeight) * 0.5f);
    ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 0.4f), "%s", text.c_str());
}

static DWORD g_ghostStartedAt = 0;
static std::string g_ghostGameTitle;
static int g_lastMilestone = -1;

static const char* GhostMilestone(DWORD sec) {
    if (sec >= 3600) return "AN HOUR ALREADY?";
    if (sec >= 1800) return "STILL CHILLING";
    if (sec >= 900) return "YOU'RE SETTLED IN";
    if (sec >= 300) return "FIRST CHILL MILESTONE";
    return "SESSION ACTIVE";
}

static const char* GhostEasterEgg(DWORD sec) {
    switch (sec) {
        case 60: return "still here? 👀";
        case 333: return "something feels familiar...";
        case 420: return "nice.";
        case 666: return "the window noticed.";
        case 777: return "lucky session.";
        case 1111: return "11:11 — make a wish.";
        case 1337: return "elite.";
        case 3600: return "you really like this window huh";
        default: return nullptr;
    }
}

void DrawGhostScreen(HDC hdc, const RECT& rc) {
    int w = rc.right - rc.left, h = rc.bottom - rc.top;
    DWORD elapsed = (GetTickCount() - g_ghostStartedAt) / 1000;
    int hh = (int)(elapsed / 3600), mm = (int)((elapsed / 60) % 60), ss = (int)(elapsed % 60);
    char timer[32]; sprintf_s(timer, "%02d:%02d:%02d", hh, mm, ss);

    // Deliberately minimal: pure black screen with one large session timer.
    HBRUSH bg = CreateSolidBrush(RGB(0, 0, 0));
    FillRect(hdc, &rc, bg); DeleteObject(bg);
    SetBkMode(hdc, TRANSPARENT);

    HFONT timerFont = CreateFontA(96,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,
        OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,"Segoe UI");
    HFONT gameFont = CreateFontA(16,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,
        OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,"Segoe UI");

    // Game name is intentionally tiny; the timer is the only focal element.
    SelectObject(hdc, gameFont); SetTextColor(hdc, RGB(120,120,120));
    RECT game = {24, 22, w-24, 48};
    DrawTextA(hdc, g_ghostGameTitle.c_str(), -1, &game, DT_CENTER | DT_SINGLELINE);

    SelectObject(hdc, timerFont); SetTextColor(hdc, RGB(245,245,245));
    RECT tr = {20, (h/2)-70, w-20, (h/2)+70};
    DrawTextA(hdc, timer, -1, &tr, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

    DeleteObject(timerFont); DeleteObject(gameFont);
}

LRESULT CALLBACK GhostProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    if (uMsg == WM_CREATE) { g_ghostStartedAt=GetTickCount(); SetTimer(hwnd,1,250,NULL); }
    if (uMsg == WM_TIMER) InvalidateRect(hwnd,NULL,FALSE);
    if (uMsg == WM_DESTROY) { KillTimer(hwnd,1); PostQuitMessage(0); }
    if (uMsg == WM_PAINT) { PAINTSTRUCT ps; HDC hdc=BeginPaint(hwnd,&ps); RECT rc; GetClientRect(hwnd,&rc); DrawGhostScreen(hdc,rc); EndPaint(hwnd,&ps); return 0; }
    return DefWindowProcA(hwnd,uMsg,wParam,lParam);
}

void RunAsFakeGame(std::string windowTitle) {
    g_ghostGameTitle=windowTitle;
    const char* CLASS_NAME="ChillXQuestGhostClass";
    WNDCLASSEXA wc={0}; wc.cbSize=sizeof(WNDCLASSEXA); wc.lpfnWndProc=GhostProc; wc.hInstance=GetModuleHandle(NULL); wc.lpszClassName=CLASS_NAME;
    wc.hbrBackground=(HBRUSH)GetStockObject(BLACK_BRUSH); wc.hIcon=LoadIcon(wc.hInstance,MAKEINTRESOURCE(IDI_ICON1)); wc.hIconSm=wc.hIcon;
    if(!wc.hIcon) wc.hIcon=LoadIcon(NULL,IDI_APPLICATION); if(!wc.hIconSm) wc.hIconSm=wc.hIcon;
    RegisterClassExA(&wc);
    HWND hwnd=CreateWindowExA(0,CLASS_NAME,windowTitle.c_str(),WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,800,600,NULL,NULL,GetModuleHandle(NULL),NULL);
    ShowWindow(hwnd,SW_SHOWNORMAL); UpdateWindow(hwnd);
    MSG msg={}; while(GetMessageA(&msg,NULL,0,0)>0){TranslateMessage(&msg);DispatchMessageA(&msg);}
}

struct RunningGame {
    GameInfo info;
    std::string activeExePath;
    PROCESS_INFORMATION pi = { 0 };
    bool isRunning = false;
};

std::string GetCurrentDirectoryString() {
    char buffer[MAX_PATH];
    GetModuleFileNameA(NULL, buffer, MAX_PATH);
    std::string path(buffer);
    size_t lastSlash = path.find_last_of("\\/");
    return path.substr(0, lastSlash);
}

std::string SanitizeDirectoryName(std::string name) {
    const std::string invalidChars = "\\/:*?\"<>|";
    for (char& c : name) {
        if (invalidChars.find(c) != std::string::npos) {
            c = '_';
        }
    }
    return name;
}

bool StartGhostProcess(RunningGame& game, std::string chosenExe, std::string relativeExePath) {
    std::string rootDir = GetCurrentDirectoryString();
    std::string fakeGamesDir = rootDir + "\\fake_games";
    _mkdir(fakeGamesDir.c_str());

    std::string safeGameName = SanitizeDirectoryName(game.info.name);
    std::string gameDir = fakeGamesDir + "\\" + safeGameName;
    _mkdir(gameDir.c_str());

    std::string normalizedPath = relativeExePath;
    std::replace(normalizedPath.begin(), normalizedPath.end(), '/', '\\');

    std::string exeDir = gameDir;
    size_t lastSlash = normalizedPath.find_last_of('\\');
    if (lastSlash != std::string::npos) {
        std::string subDirs = normalizedPath.substr(0, lastSlash);
        std::stringstream ss(subDirs);
        std::string part;
        while (std::getline(ss, part, '\\')) {
            if (part.empty()) continue;
            exeDir += "\\" + part;
            _mkdir(exeDir.c_str());
        }
    }

    std::string destExe = exeDir + "\\" + chosenExe;
    std::string configFile = exeDir + "\\" + CONFIG_FILENAME;

    char myPath[MAX_PATH];
    GetModuleFileNameA(NULL, myPath, MAX_PATH);

    if (!CopyFileA(myPath, destExe.c_str(), FALSE)) return false;

    std::ofstream cfg(configFile);
    if (cfg.is_open()) {
        cfg << game.info.name;
        cfg.close();
    }

    STARTUPINFOA si; ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
    ZeroMemory(&game.pi, sizeof(game.pi));

    std::string cmdLine = "\"" + destExe + "\"";

    if (CreateProcessA(NULL, (LPSTR)cmdLine.c_str(), NULL, NULL, FALSE, 0, NULL, (LPCSTR)exeDir.c_str(), &si, &game.pi)) {
        game.isRunning = true;
        game.activeExePath = destExe;
        return true;
    }
    return false;
}

void StopGhostProcess(RunningGame& game) {
    if (game.isRunning) {
        TerminateProcess(game.pi.hProcess, 0); WaitForSingleObject(game.pi.hProcess, 2000);
        CloseHandle(game.pi.hProcess); CloseHandle(game.pi.hThread);

        std::string exePath = game.activeExePath;

        size_t lastSlash = exePath.find_last_of("\\/");
        std::string dirPath = exePath.substr(0, lastSlash);
        std::string cfgPath = dirPath + "\\" + CONFIG_FILENAME;

        for (int i = 0; i < 10; i++) {
            DeleteFileA(exePath.c_str());
            DeleteFileA(cfgPath.c_str());
            Sleep(100);
            if (GetFileAttributesA(exePath.c_str()) == INVALID_FILE_ATTRIBUTES) break;
        }
        game.isRunning = false;
    }
}

void SetupChillXQuestStyle() {
    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowRounding = 20.0f; style.FrameRounding = 14.0f; style.ChildRounding = 16.0f;
    style.PopupRounding = 16.0f; style.ScrollbarRounding = 12.0f; style.GrabRounding = 12.0f;
    style.WindowPadding = ImVec2(15, 15); style.ItemSpacing = ImVec2(12, 12);
    style.ButtonTextAlign = ImVec2(0.5f, 0.5f); style.WindowBorderSize = 0.0f;
    style.ChildBorderSize = 1.0f; style.FrameBorderSize = 0.0f;
    ImVec4* colors = style.Colors;
    colors[ImGuiCol_WindowBg] = ImVec4(0, 0, 0, 0); colors[ImGuiCol_FrameBg] = colBoxBg;
    colors[ImGuiCol_ChildBg] = colBoxBg; colors[ImGuiCol_PopupBg] = ImVec4(0.129f, 0.102f, 0.227f, 0.96f);
    colors[ImGuiCol_Border] = colBorder; colors[ImGuiCol_Text] = colTextLight;
    colors[ImGuiCol_TextDisabled] = ImVec4(0.5f, 0.5f, 0.5f, 1.0f);
    colors[ImGuiCol_Button] = ImVec4(0.545f, 0.361f, 0.965f, 0.45f);
    colors[ImGuiCol_ButtonHovered] = ImVec4(0.769f, 0.710f, 0.992f, 0.65f);
    colors[ImGuiCol_ButtonActive] = colPrimary;
    colors[ImGuiCol_Header] = ImVec4(0.545f, 0.361f, 0.965f, 0.35f); colors[ImGuiCol_HeaderHovered] = colAccent;
}

static ID3D11Device* g_pd3dDevice = nullptr;
static ID3D11DeviceContext* g_pd3dDeviceContext = nullptr;
static IDXGISwapChain* g_pSwapChain = nullptr;
static ID3D11RenderTargetView* g_mainRenderTargetView = nullptr;
bool CreateDeviceD3D(HWND hWnd);
void CleanupDeviceD3D();
void CreateRenderTarget();
void CleanupRenderTarget();
LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

int main(int argc, char** argv) {
    atexit(CleanupTempFiles);

    char myPath[MAX_PATH];
    GetModuleFileNameA(NULL, myPath, MAX_PATH);

    std::string oldExePath = std::string(myPath) + ".old";
    if (GetFileAttributesA(oldExePath.c_str()) != INVALID_FILE_ATTRIBUTES) {
        DeleteFileA(oldExePath.c_str());
    }
    CheckForUpdates();

    std::string currentExe(myPath);

    size_t lastSlash = currentExe.find_last_of("\\/");
    std::string currentDir = currentExe.substr(0, lastSlash);
    std::string configFile = currentDir + "\\" + CONFIG_FILENAME;

    if (GetFileAttributesA(configFile.c_str()) != INVALID_FILE_ATTRIBUTES) {
        std::string gameTitle = "Game";
        std::ifstream f(configFile);
        if (f.is_open()) {
            std::getline(f, gameTitle);
            f.close();
        }
        RunAsFakeGame(gameTitle);
        return 0;
    }

    WNDCLASSEXW wc = { sizeof(wc), CS_CLASSDC, WndProc, 0L, 0L, GetModuleHandle(nullptr), nullptr, nullptr, nullptr, nullptr, L"ChillXQuest", nullptr };
    wc.hIcon = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1));
    wc.hIconSm = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1));
    ::RegisterClassExW(&wc);

    int w = 430, h = 760;
    int x = (GetSystemMetrics(SM_CXSCREEN) - w) / 2;
    int y = (GetSystemMetrics(SM_CYSCREEN) - h) / 2;
    HWND hwnd = ::CreateWindowW(wc.lpszClassName, L"CHILL × QUEST", WS_POPUP, x, y, w, h, nullptr, nullptr, wc.hInstance, nullptr);
    MARGINS margins = { -1 }; DwmExtendFrameIntoClientArea(hwnd, &margins);

    if (!CreateDeviceD3D(hwnd)) { CleanupDeviceD3D(); return 1; }
    ::ShowWindow(hwnd, SW_SHOWDEFAULT);
    ::UpdateWindow(hwnd);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = NULL;
    SetupChillXQuestStyle();

    ImFontConfig fontConfig; fontConfig.FontDataOwnedByAtlas = false;
    ImFont* fontRegular = io.Fonts->AddFontFromMemoryTTF((void*)font_regular_data, sizeof(font_regular_data), 20.0f, &fontConfig);
    ImFont* fontBold = io.Fonts->AddFontFromMemoryTTF((void*)font_bold_data, sizeof(font_bold_data), 20.0f, &fontConfig);
    if (!fontRegular) fontRegular = io.Fonts->AddFontDefault();
    if (!fontBold) fontBold = io.Fonts->AddFontDefault();

    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(g_pd3dDevice, g_pd3dDeviceContext);

    auto db = FetchGameDatabase();
    std::vector<RunningGame> activeGames;
    static char searchBuf[128] = "";
    GameInfo* currentSelectedGame = nullptr;
    bool done = false;

    while (!done) {
        MSG msg;
        while (::PeekMessage(&msg, nullptr, 0U, 0U, PM_REMOVE)) {
            ::TranslateMessage(&msg); ::DispatchMessage(&msg);
            if (msg.message == WM_QUIT) done = true;
        }
        if (done) break;

        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();
        ImGuiStyle& style = ImGui::GetStyle();

        ImGui::SetNextWindowPos(ImVec2(0, 0));
        ImGui::SetNextWindowSize(ImGui::GetIO().DisplaySize);
        ImGui::Begin("Main", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
        g_CanDrag = !ImGui::IsAnyItemHovered() && !ImGui::IsAnyItemActive();

        ImDrawList* draw_list = ImGui::GetWindowDrawList();
        draw_list->AddRectFilled(ImVec2(0, 0), ImVec2((float)w, (float)h), IM_COL32(13, 11, 26, 245), 20.0f);
        draw_list->AddRect(ImVec2(1, 1), ImVec2((float)w - 1, (float)h - 1), IM_COL32(196, 181, 253, 65), 20.0f, 0, 1.0f);

        ImGui::PushFont(fontBold);
        ImGui::AlignTextToFramePadding();
        std::string verText = CURRENT_VERSION + " Stable";
        ImGui::TextColored(ImVec4(1, 1, 1, 0.5f), "%s", verText.c_str());
        ImGui::SameLine(); ImGui::TextColored(ImVec4(1, 1, 1, 0.5f), "|"); ImGui::SameLine();

        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(1, 1, 1, 0.15f));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1, 1, 1, 0.25f));
        // GitHub Button
        if (ImGui::Button("GITHUB"))
            ShellExecuteA(NULL, "open", "https://github.com/hallow3316", NULL, NULL, SW_SHOWNORMAL);

        ImGui::SameLine();

        // Discord Button
        if (ImGui::Button("DISCORD"))
            ShellExecuteA(NULL, "open", "https://discord.com/users/1450134275122003990", NULL, NULL, SW_SHOWNORMAL);

        // Pop styles only after both buttons are drawn
        ImGui::PopStyleColor(2);
        ImGui::PopFont();

        float smallBtnSize = 18.0f;
        ImGui::SameLine(ImGui::GetWindowWidth() - (smallBtnSize * 2) - 30.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(0, 0));
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(1, 1, 1, 0.1f));
        if (ImGui::Button("-", ImVec2(smallBtnSize, smallBtnSize))) ShowWindow(hwnd, SW_MINIMIZE);
        ImGui::SameLine();
        if (ImGui::Button("X", ImVec2(smallBtnSize, smallBtnSize))) done = true;
        ImGui::PopStyleColor(); ImGui::PopStyleVar(); ImGui::Separator();

        ImGui::Spacing();
        float winWidth = ImGui::GetWindowWidth();
        ImGui::PushFont(fontBold); ImGui::SetWindowFontScale(3.5f);
        std::string title = "CHILL × QUEST";
        float titleW = ImGui::CalcTextSize(title.c_str()).x;
        ImGui::SetCursorPosX((winWidth - titleW) * 0.5f);
        ImGui::TextColored(colAccent, title.c_str());
        ImGui::SetWindowFontScale(1.0f); ImGui::PopFont();
        ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 25.0f);

        ImGui::PushFont(fontRegular); ImGui::SetWindowFontScale(1.2f);
        std::string sub = "DISCORD QUEST HUB";
        float subW = ImGui::CalcTextSize(sub.c_str()).x;
        ImGui::SetCursorPosX((winWidth - subW) * 0.5f);
        ImGui::TextColored(colTextGrey, sub.c_str());
        ImGui::SetWindowFontScale(1.0f); ImGui::PopFont();

        ImGui::Spacing(); ImGui::Spacing();

        ImGui::PushFont(fontRegular); ImGui::SetCursorPosX(30);
        ImGui::PushItemWidth(winWidth - 60);
        ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(10, 10));
        ImGui::InputTextWithHint("##search", "Search game...", searchBuf, IM_ARRAYSIZE(searchBuf));
        ImGui::PopStyleVar(); ImGui::PopItemWidth(); ImGui::PopFont(); ImGui::Spacing();

        ImGui::PushFont(fontBold); ImGui::TextColored(ImVec4(1, 1, 1, 0.8f), "Search Results:"); ImGui::PopFont();

        ImGui::BeginChild("ResultsBox", ImVec2(0, 180), true);
        std::string searchQ = ToLower(searchBuf);

        if (searchQ.length() > 0) {
            bool found = false;
            for (auto& game : db) {
                if (ToLower(game.name).find(searchQ) != std::string::npos) {
                    found = true;
                    ImGui::BeginChild(game.name.c_str(), ImVec2(0, 55), true, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
                    float textH = ImGui::GetTextLineHeight();
                    ImGui::SetCursorPosY((55.0f - textH) * 0.5f); ImGui::SetCursorPosX(15.0f);
                    ImGui::PushFont(fontBold); ImGui::Text("%s", game.name.c_str()); ImGui::PopFont();
                    float btnH = 30.0f; float btnW = 90.0f;
                    ImGui::SetCursorPosY((55.0f - btnH) * 0.5f); ImGui::SetCursorPosX(ImGui::GetWindowWidth() - btnW - 15.0f);
                    ImGui::PushFont(fontBold);
                    if (ImGui::Button("SELECT", ImVec2(btnW, btnH))) currentSelectedGame = &game;
                    ImGui::PopFont(); ImGui::EndChild();
                }
            }
            if (!found) TextCentered("No results found.");
        }
        else { TextCentered("Type a game name above..."); }
        ImGui::EndChild();

        ImGui::Spacing(); ImGui::Separator(); ImGui::Spacing();

        float footerHeight = 40.0f; float bottomMargin = 10.0f;
        if (currentSelectedGame != nullptr) {
            ImGui::PushFont(fontBold); ImGui::TextColored(colAccent, "SELECTED GAME:"); ImGui::PopFont();
            float boxHeight = ImGui::GetContentRegionAvail().y - footerHeight - bottomMargin;
            ImGui::BeginChild("SelectionBox", ImVec2(0, boxHeight), true);
            ImGui::PushFont(fontBold); ImGui::SetWindowFontScale(1.2f);
            ImGui::Text("%s", currentSelectedGame->name.c_str()); ImGui::SetWindowFontScale(1.0f); ImGui::PopFont();
            ImGui::PushFont(fontRegular); ImGui::TextDisabled("ID: %s", currentSelectedGame->id.c_str());
            ImGui::Separator(); ImGui::Spacing(); ImGui::Text("Available versions:"); ImGui::PopFont();
            float availWidth = ImGui::GetContentRegionAvail().x;
            int numExecutables = (int)currentSelectedGame->executables.size();
            float spacing = style.ItemSpacing.x; float halfWidth = (availWidth - spacing) * 0.5f;

            ImGui::PushFont(fontBold);
            for (int i = 0; i < numExecutables; ++i) {
                const auto& exe = currentSelectedGame->executables[i];
                const auto& exePath = currentSelectedGame->executablePaths[i];
                bool alreadyRunning = false;
                std::vector<RunningGame>::iterator activeGameIt;
                for (auto it = activeGames.begin(); it != activeGames.end(); ++it) {
                    if (it->activeExePath.find(exe) != std::string::npos && it->isRunning) {
                        alreadyRunning = true; activeGameIt = it; break;
                    }
                }
                float currentBtnWidth = halfWidth;
                if (numExecutables % 2 != 0 && i == numExecutables - 1) currentBtnWidth = availWidth;

                if (alreadyRunning) {
                    ImGui::PushStyleColor(ImGuiCol_Button, colBtnStop);
                    if (ImGui::Button(("STOP: " + exe).c_str(), ImVec2(currentBtnWidth, 30))) {
                        StopGhostProcess(*activeGameIt); activeGames.erase(activeGameIt);
                    }
                    ImGui::PopStyleColor();
                }
                else {
                    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.06f, 0.72f, 0.83f, 0.5f));
                    if (ImGui::Button(("START: " + exe).c_str(), ImVec2(currentBtnWidth, 30))) {
                        RunningGame rg; rg.info = *currentSelectedGame;
                        if (StartGhostProcess(rg, exe, exePath)) activeGames.push_back(rg);
                    }
                    ImGui::PopStyleColor();
                }
                if (i % 2 == 0 && i < numExecutables - 1) ImGui::SameLine();
            }
            ImGui::PopFont(); ImGui::EndChild();
        }
        else {
            float boxHeight = ImGui::GetContentRegionAvail().y - footerHeight - bottomMargin;
            ImGui::BeginChild("SelectionBox", ImVec2(0, boxHeight), true);
            TextCentered("No game selected."); ImGui::EndChild();
        }

        float windowHeight = ImGui::GetWindowHeight(); float footerStartY = windowHeight - 40.0f;
        ImGui::SetCursorPosY(footerStartY); ImGui::Separator();
        float textLineHeight = ImGui::GetTextLineHeight(); float textCenterY = footerStartY + (40.0f - textLineHeight) * 0.5f;
        std::string t1 = "dev by "; std::string t2 = "HALLOW";
        float totalW = ImGui::CalcTextSize(t1.c_str()).x + ImGui::CalcTextSize(t2.c_str()).x;
        float textX = (ImGui::GetWindowWidth() - totalW) * 0.5f;
        ImGui::SetCursorPos(ImVec2(textX, textCenterY));
        ImGui::PushFont(fontRegular); ImGui::TextDisabled("%s", t1.c_str()); ImGui::PopFont();
        ImGui::SameLine(0, 0);
        ImGui::PushFont(fontBold); ImGui::TextColored(colAccent, "%s", t2.c_str()); ImGui::PopFont();

        ImGui::End(); ImGui::Render();
        const float clear_color[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
        g_pd3dDeviceContext->OMSetRenderTargets(1, &g_mainRenderTargetView, nullptr);
        g_pd3dDeviceContext->ClearRenderTargetView(g_mainRenderTargetView, clear_color);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        g_pSwapChain->Present(1, 0);
    }

    for (auto& g : activeGames) StopGhostProcess(g);
    ImGui_ImplDX11_Shutdown(); ImGui_ImplWin32_Shutdown(); ImGui::DestroyContext();
    CleanupDeviceD3D(); ::DestroyWindow(hwnd); ::UnregisterClassW(wc.lpszClassName, wc.hInstance);
    return 0;
}

bool CreateDeviceD3D(HWND hWnd) {
    DXGI_SWAP_CHAIN_DESC sd; ZeroMemory(&sd, sizeof(sd));
    sd.BufferCount = 2; sd.BufferDesc.Width = 0; sd.BufferDesc.Height = 0;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate.Numerator = 60; sd.BufferDesc.RefreshRate.Denominator = 1;
    sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH; sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hWnd; sd.SampleDesc.Count = 1; sd.SampleDesc.Quality = 0;
    sd.Windowed = TRUE; sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
    UINT createDeviceFlags = 0; D3D_FEATURE_LEVEL featureLevel;
    const D3D_FEATURE_LEVEL featureLevelArray[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0, };
    if (D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, createDeviceFlags, featureLevelArray, 2, D3D11_SDK_VERSION, &sd, &g_pSwapChain, &g_pd3dDevice, &featureLevel, &g_pd3dDeviceContext) != S_OK) return false;
    CreateRenderTarget(); return true;
}
void CleanupDeviceD3D() { CleanupRenderTarget(); if (g_pSwapChain) g_pSwapChain->Release(); if (g_pd3dDeviceContext) g_pd3dDeviceContext->Release(); if (g_pd3dDevice) g_pd3dDevice->Release(); }
void CreateRenderTarget() { ID3D11Texture2D* pBackBuffer; g_pSwapChain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer)); g_pd3dDevice->CreateRenderTargetView(pBackBuffer, nullptr, &g_mainRenderTargetView); pBackBuffer->Release(); }
void CleanupRenderTarget() { if (g_mainRenderTargetView) { g_mainRenderTargetView->Release(); g_mainRenderTargetView = nullptr; } }
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam)) return true;
    switch (msg) {
    case WM_SIZE: if (g_pd3dDevice != nullptr && wParam != SIZE_MINIMIZED) { CleanupRenderTarget(); g_pSwapChain->ResizeBuffers(0, (UINT)LOWORD(lParam), (UINT)HIWORD(lParam), DXGI_FORMAT_UNKNOWN, 0); CreateRenderTarget(); } return 0;
    case WM_NCHITTEST: { LRESULT hit = DefWindowProc(hWnd, msg, wParam, lParam); if (hit == HTCLIENT && g_CanDrag) return HTCAPTION; return hit; }
    case WM_DESTROY: ::PostQuitMessage(0); return 0;
    } return ::DefWindowProcW(hWnd, msg, wParam, lParam);
}